import { useState, type CSSProperties } from "react";
import { SECTIONS } from "../sections/registry.ts";
import { useScrollerStore } from "../store/useScrollerStore.ts";
import { useMovieStore } from "../store/useMovieStore.ts";

/** Chapter that owns the movie panel; the controls live only there. */
const MOVIE_CHAPTER = "alpha6";

function PlayIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path className="ef-movie-glyph-fill" d="M8.5 5.4 19 12 8.5 18.6V5.4Z" />
    </svg>
  );
}

function PauseIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <g className="ef-movie-glyph-fill">
        <path d="M8 5.2h3.1v13.6H8z" />
        <path d="M12.9 5.2H16v13.6h-3.1z" />
      </g>
    </svg>
  );
}

function ReplayIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <g className="ef-movie-glyph-stroke">
        <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
        <path d="M3 3v5h5" />
      </g>
    </svg>
  );
}

function SpeakerIcon({ muted }: { muted: boolean }) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path className="ef-speaker" d="M4 9.1h3.6L12.5 5v14l-4.9-4.1H4V9.1Z" />
      {muted ? (
        <g className="ef-sound-muted">
          <path d="m16.2 9.2 5.1 5.6" />
          <path d="m21.3 9.2-5.1 5.6" />
        </g>
      ) : (
        <g className="ef-sound-waves">
          <path d="M16.1 8.6a4.9 4.9 0 0 1 0 6.8" />
          <path d="M18.8 5.9a8.8 8.8 0 0 1 0 12.2" />
        </g>
      )}
    </svg>
  );
}

function FullscreenIcon({ on }: { on: boolean }) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <g className="ef-movie-glyph-stroke">
        {on ? (
          <>
            <path d="M9.5 4.5v5h-5" />
            <path d="M14.5 4.5v5h5" />
            <path d="M9.5 19.5v-5h-5" />
            <path d="M14.5 19.5v-5h5" />
          </>
        ) : (
          <>
            <path d="M4.5 9.5v-5h5" />
            <path d="M19.5 9.5v-5h-5" />
            <path d="M4.5 14.5v5h5" />
            <path d="M19.5 14.5v5h-5" />
          </>
        )}
      </g>
    </svg>
  );
}

/**
 * Chapter 02's player: play/pause, restart from the beginning, mute/unmute and
 * fullscreen for `final_movie_03.mp4`. Fullscreen is the chapter's screening
 * mode — it takes over with sound on and the movie rewound to the top. The
 * video element belongs to the three scene, so every click is routed through
 * `useMovieStore` rather than a ref.
 */
export function MovieControls() {
  const activeIndex = useScrollerStore((state) => state.activeIndex);
  const section = SECTIONS[activeIndex] ?? SECTIONS[0];
  const visible = section.id === MOVIE_CHAPTER;

  const attached = useMovieStore((state) => state.attached);
  const available = useMovieStore((state) => state.available);
  const playing = useMovieStore((state) => state.playing);
  const muted = useMovieStore((state) => state.muted);
  const fullscreen = useMovieStore((state) => state.fullscreen);
  const fullscreenEnabled = useMovieStore((state) => state.fullscreenEnabled);
  const togglePlay = useMovieStore((state) => state.togglePlay);
  const restart = useMovieStore((state) => state.restart);
  const toggleMute = useMovieStore((state) => state.toggleMute);
  const toggleFullscreen = useMovieStore((state) => state.toggleFullscreen);

  // Re-keying the glyph replays its CSS spin, so a restart is visible even
  // when the movie was already playing.
  const [replayTick, setReplayTick] = useState(0);

  const ready = attached && available;

  return (
    <div
      className="ef-movie-controls"
      data-visible={visible}
      data-armed={ready}
      style={{ "--accent": section.accent } as CSSProperties}
      role="group"
      aria-label="Movie controls"
      aria-hidden={visible ? undefined : true}
    >
      <button
        type="button"
        className="ef-movie-control"
        data-on={playing}
        onClick={togglePlay}
        disabled={!ready}
        aria-pressed={playing}
        aria-label={playing ? "Pause the movie" : "Play the movie"}
        title={playing ? "Pause" : "Play"}
        tabIndex={visible ? undefined : -1}
      >
        {playing ? <PauseIcon /> : <PlayIcon />}
      </button>

      <button
        type="button"
        className="ef-movie-control"
        onClick={() => {
          restart();
          setReplayTick((tick) => tick + 1);
        }}
        disabled={!ready}
        aria-label="Start the movie from the beginning"
        title="Start from beginning"
        tabIndex={visible ? undefined : -1}
      >
        <span
          key={replayTick}
          className="ef-movie-replay"
          data-spin={replayTick > 0}
        >
          <ReplayIcon />
        </span>
      </button>

      <button
        type="button"
        className="ef-movie-control"
        data-on={!muted}
        onClick={toggleMute}
        disabled={!ready}
        aria-pressed={!muted}
        aria-label={muted ? "Unmute the movie" : "Mute the movie"}
        title={muted ? "Unmute" : "Mute"}
        tabIndex={visible ? undefined : -1}
      >
        <SpeakerIcon muted={muted} />
      </button>

      {fullscreenEnabled ? (
        <button
          type="button"
          className="ef-movie-control"
          data-on={fullscreen}
          onClick={toggleFullscreen}
          disabled={!ready}
          aria-pressed={fullscreen}
          aria-label={
            fullscreen
              ? "Leave fullscreen"
              : "Play the movie in fullscreen, from the beginning, with sound"
          }
          title={
            fullscreen ? "Exit fullscreen" : "Fullscreen · sound on, from start"
          }
          tabIndex={visible ? undefined : -1}
        >
          <FullscreenIcon on={fullscreen} />
        </button>
      ) : null}
    </div>
  );
}
