import * as THREE from "three/webgpu";
import { color as tslColor, texture as tslTexture } from "three/tsl";
import type { SectionPhaseState } from "../../lib/scroll-phases.ts";
import {
  FINAL_MOVIE_SOURCES,
  loadFirstAsset,
} from "../../lib/asset-sources.ts";
import { useMovieStore } from "../../store/useMovieStore.ts";
import { useScrollerStore } from "../../store/useScrollerStore.ts";
import { SECTIONS } from "../registry.ts";
import type { Pointer } from "../shared.ts";

/* ── 02 Alpha 6: final_movie_03.mp4 playing inside the shard ring ────────── */

const HOME = new THREE.Vector3(0, 0.05, 0.6);
// The plate is the chapter's centrepiece, so it takes most of the frame; the
// shard ring sits behind it in depth, not in the way.
const MAX_WIDTH = 4.7;
const MAX_HEIGHT = 2.65;
// The blue halo hugs the plate instead of boxing it in.
const GLOW_SCALE_X = 1.14;
const GLOW_SCALE_Y = 1.18;
const CENTER_FOV = 42;
// The exterior chapters park their camera at z = 9.6 (see frameChapterCamera).
const CAMERA_HOME_Z = 9.6;

/** How wide the viewport is at the screen's own depth. */
function visibleWidth(aspect: number) {
  const distance = CAMERA_HOME_Z - HOME.z;
  const visibleHeight = 2 * Math.tan((CENTER_FOV * Math.PI) / 360) * distance;
  return visibleHeight * aspect;
}

/** Points a detached <video> at `source` and resolves once metadata lands. */
function openVideo(video: HTMLVideoElement, source: string) {
  return new Promise<HTMLVideoElement>((resolve, reject) => {
    const cleanup = () => {
      video.removeEventListener("loadedmetadata", onLoad);
      video.removeEventListener("error", onError);
    };
    const onLoad = () => {
      cleanup();
      resolve(video);
    };
    const onError = () => {
      cleanup();
      reject(new Error(`video unavailable: ${source}`));
    };

    video.addEventListener("loadedmetadata", onLoad);
    video.addEventListener("error", onError);
    video.src = source;
    video.load();
  });
}

/**
 * The chapter's centrepiece: `final_movie_03.mp4` on a glass-framed panel the
 * shard ring orbits. The frame is drawn with the chapter's accent, the movie
 * itself is sampled straight into an unlit `texture()` node (untinted, so it
 * keeps its own values inside the glow field), and the plate stays square to
 * the viewer while the shards keep spinning.
 */
export function createFinalMovie(accent: string) {
  const mount = new THREE.Group();
  mount.position.copy(HOME);

  // Everything inside `rect` shares one scale, so the frame hugs the movie
  // whatever aspect the file turns out to be.
  const rect = new THREE.Group();
  mount.add(rect);

  const frameMaterial = new THREE.LineBasicNodeMaterial();
  frameMaterial.colorNode = tslColor(accent);
  frameMaterial.transparent = true;
  frameMaterial.opacity = 0.55;
  frameMaterial.depthWrite = false;
  frameMaterial.blending = THREE.AdditiveBlending;

  const outlineGeometry = new THREE.PlaneGeometry(1, 1);
  const frameGeometry = new THREE.EdgesGeometry(outlineGeometry, 28);
  outlineGeometry.dispose();

  const frame = new THREE.LineSegments(frameGeometry, frameMaterial);
  // Nudge the outline toward the camera so it never z-fights the plate.
  frame.position.z = 0.012;
  rect.add(frame);

  const glowMaterial = new THREE.MeshBasicNodeMaterial();
  glowMaterial.colorNode = tslColor(accent);
  glowMaterial.transparent = true;
  glowMaterial.opacity = 0.26;
  glowMaterial.depthWrite = false;
  glowMaterial.blending = THREE.AdditiveBlending;
  glowMaterial.side = THREE.DoubleSide;

  const glow = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), glowMaterial);
  glow.position.z = -0.18;
  mount.add(glow);

  // A detached video still decodes; keeping it in the DOM is what Safari wants
  // before it will start a muted, inline, looping playback. The element stays
  // parked off-screen by `.ef-movie-source` (landing.css), which also expands
  // it to the viewport when the player goes fullscreen.
  const video = document.createElement("video");
  video.muted = true;
  video.defaultMuted = true;
  video.loop = true;
  video.playsInline = true;
  video.preload = "auto";
  video.crossOrigin = "anonymous";
  video.className = "ef-movie-source";
  video.setAttribute("playsinline", "");
  video.setAttribute("aria-hidden", "true");
  document.body.appendChild(video);

  // React's player controls drive this element through the movie store.
  const movieStore = useMovieStore.getState();
  movieStore.attach(video);

  // The stage keeps every chapter's world alive, so scrolling away would leave
  // the movie decoding — and audibly looping after a fullscreen screening.
  // Chapter 02 watches the scroller and stops the movie on the handoff out,
  // then picks it up again when the chapter comes back.
  const chapterIndex = SECTIONS.findIndex((section) => section.id === "alpha6");
  const chapterIsOnScreen = () => {
    const state = useScrollerStore.getState();
    return state.fromIndex === chapterIndex || state.toIndex === chapterIndex;
  };
  let chapterOnScreen = chapterIsOnScreen();
  const unsubscribeScroll = useScrollerStore.subscribe((state) => {
    const onScreen =
      state.fromIndex === chapterIndex || state.toIndex === chapterIndex;
    if (onScreen === chapterOnScreen) return;
    chapterOnScreen = onScreen;
    if (onScreen) movieStore.play();
    else movieStore.pause();
  });

  let texture: THREE.VideoTexture | null = null;
  let screenMaterial: THREE.MeshBasicNodeMaterial | null = null;
  let natural = { width: 16, height: 9 };
  let viewportAspect = 1.6;
  let targetOpacity = 0;
  let disposed = false;

  const fitToView = (aspect: number) => {
    viewportAspect = aspect;
    // Take more of the viewport than before; the ring orbits behind the plate.
    const maxWidth = THREE.MathUtils.clamp(
      visibleWidth(aspect) * 0.47,
      2,
      MAX_WIDTH,
    );
    const scale = Math.min(maxWidth / natural.width, MAX_HEIGHT / natural.height);
    const width = Math.max(0.6, natural.width * scale);
    const height = Math.max(0.4, natural.height * scale);

    rect.scale.set(width, height, 1);
    glow.scale.set(width * GLOW_SCALE_X, height * GLOW_SCALE_Y, 1);
  };
  fitToView(viewportAspect);

  // Autoplay only ever starts muted; a first gesture retries if the browser
  // refused, and the panel simply stays dark if the file cannot play. It also
  // stays quiet while the chapter is scrolled away.
  const play = () => {
    if (disposed || !chapterOnScreen) return;
    void video.play().catch(() => {
      // Left to the pointerdown retry below.
    });
  };

  const onPlaying = () => {
    targetOpacity = 0.96;
  };
  video.addEventListener("playing", onPlaying);

  const unlock = () => play();
  window.addEventListener("pointerdown", unlock, { passive: true });

  void loadFirstAsset(FINAL_MOVIE_SOURCES, (source) =>
    openVideo(video, source),
  )
    .then((loaded) => {
      if (!loaded || disposed) {
        if (!loaded) {
          console.warn("final_movie_03.mp4 unavailable; the panel stays dark.");
        }
        return;
      }

      if (video.videoWidth && video.videoHeight) {
        natural = { width: video.videoWidth, height: video.videoHeight };
      }

      texture = new THREE.VideoTexture(video);
      texture.colorSpace = THREE.SRGBColorSpace;
      // Straight sampling: no mip chain to build while frames keep arriving.
      texture.generateMipmaps = false;
      texture.minFilter = THREE.LinearFilter;
      texture.magFilter = THREE.LinearFilter;

      const material = new THREE.MeshBasicNodeMaterial();
      // Sample the movie straight into the unlit plate; a touch of gain keeps
      // it from going flat under the compositor's ACES curve.
      material.colorNode = tslTexture(texture).rgb.mul(1.08);
      material.transparent = true;
      material.opacity = 0;
      material.depthWrite = false;
      material.side = THREE.FrontSide;

      screenMaterial = material;
      rect.add(new THREE.Mesh(new THREE.PlaneGeometry(1, 1), material));
      fitToView(viewportAspect);
      play();
    })
    .catch(() => {
      // The chapter still renders: the frame and halo stand in for the movie.
    });

  const update = (
    time: number,
    pointer: Pointer,
    phase?: SectionPhaseState,
    /** The chapter spins its group forever; pass that yaw so the plate can
     *  cancel it and stay readable while the shards keep orbiting. */
    yaw = 0,
  ) => {
    const leaving = phase?.phase === "exit" ? phase.progress : 0;
    const arriving = phase?.phase === "enter" ? 1 - phase.progress : 0;

    mount.position.y =
      HOME.y + Math.sin(time * 0.5) * 0.045 + arriving * 0.3 - leaving * 0.6;
    mount.rotation.y =
      -yaw + Math.sin(time * 0.3) * 0.06 + pointer.x * 0.05 + leaving * 0.6;
    mount.rotation.x = Math.sin(time * 0.37) * 0.02 - pointer.y * 0.05;
    mount.rotation.z = Math.sin(time * 0.9) * 0.01;

    if (screenMaterial) {
      const target = Math.max(0, targetOpacity - leaving * 0.45);
      screenMaterial.opacity += (target - screenMaterial.opacity) * 0.12;
    }
    frameMaterial.opacity = 0.55 - leaving * 0.3;
    glowMaterial.opacity = 0.26 + Math.sin(time * 0.8) * 0.04 - leaving * 0.12;
  };

  const dispose = () => {
    disposed = true;
    unsubscribeScroll();
    window.removeEventListener("pointerdown", unlock);
    video.removeEventListener("playing", onPlaying);
    movieStore.detach(video);
    video.pause();
    video.removeAttribute("src");
    video.load();
    video.remove();

    texture?.dispose();
    texture = null;
    screenMaterial?.dispose();
    frameMaterial.dispose();
    glowMaterial.dispose();
    frameGeometry.dispose();
    glow.geometry.dispose();
    rect.traverse((object) => {
      const mesh = object as THREE.Mesh;
      mesh.geometry?.dispose();
    });
  };

  return { mount, fitToView, update, dispose };
}
