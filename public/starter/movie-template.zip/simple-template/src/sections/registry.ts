/**
 * Chapter registry. Every section is one scene in the vertical story: a name,
 * a chapter label, an accent and a background surface.
 *
 * Order matters: index 0 is the opening chapter the visitor lands on, and the
 * HUD numbers, hash routes (`#/scene-01`…), scroll anchors and transition pairs
 * are all derived from this array. The kinetic glass title opens the story and
 * the Alpha 6 movie plays second.
 */
export type SectionMeta = {
  id: string;
  index: number;
  chapter: string;
  name: string;
  accent: string;
  surface: string;
};

export const SECTIONS: SectionMeta[] = [
  {
    id: 'kinetic',
    index: 0,
    chapter: '01',
    name: 'Kinetic',
    accent: '#c5e6ff',
    surface: '#021019',
  },
  {
    id: 'alpha6',
    index: 1,
    chapter: '02',
    name: 'Alpha 6',
    accent: '#4aa8ff',
    surface: '#04101f',
  },
  {
    id: 'soft-room',
    index: 2,
    chapter: '03',
    name: 'Soft Room',
    accent: '#f47ba4',
    surface: '#0b0a09',
  },
  {
    id: 'force-shield',
    index: 3,
    chapter: '04',
    name: 'Force Shield',
    accent: '#26aeff',
    surface: '#0e0d0c',
  },
  {
    id: 'apartment',
    index: 4,
    chapter: '05',
    name: 'Apartment',
    accent: '#26aeff',
    surface: '#0e0d0c',
  },
  {
    id: 'live-env',
    index: 5,
    chapter: '06',
    name: 'Live Env',
    accent: '#c7a6ff',
    surface: '#0b0713',
  },
];

export const SECTION_COUNT = SECTIONS.length;
