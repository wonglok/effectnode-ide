import { create } from "zustand";

/**
 * Playback state for the Alpha 6 movie panel.
 *
 * The `<video>` element is created by `src/sections/alpha6/final-movie.ts`,
 * because three owns the `VideoTexture` that samples it. React therefore never
 * owns that element: the chapter hands it to this store on creation, and the
 * store mirrors play/pause, mute and fullscreen into React state while the
 * element's own events keep the two sides in sync.
 */
type MovieState = {
  /** A movie element exists (the panel may still be buffering). */
  attached: boolean;
  /** Enough data has arrived for playback to start. */
  available: boolean;
  playing: boolean;
  muted: boolean;
  fullscreen: boolean;
  /** False in sandboxed frames where the Fullscreen API is denied. */
  fullscreenEnabled: boolean;
  attach: (video: HTMLVideoElement) => void;
  detach: (video: HTMLVideoElement) => void;
  play: () => void;
  pause: () => void;
  togglePlay: () => void;
  /** Rewind to the first frame and keep playing (chapter 02 transport). */
  restart: () => void;
  toggleMute: () => void;
  toggleFullscreen: () => void;
};

type WebkitDocument = Document & {
  webkitFullscreenElement?: Element | null;
  webkitExitFullscreen?: () => Promise<void> | void;
};

type WebkitVideo = HTMLVideoElement & {
  webkitRequestFullscreen?: () => Promise<void> | void;
  webkitEnterFullscreen?: () => void;
};

/**
 * The element lives outside React, so it is held in module scope next to the
 * store. Hot reload can evaluate this module twice; keeping the store on the
 * window (like the scroll store) means a second copy still drives the same
 * element.
 */
let bound: HTMLVideoElement | null = null;

const doc = () => (typeof document === "undefined" ? null : document);

function fullscreenElement(): Element | null {
  const target = doc();
  if (!target) return null;
  const webkit = (target as WebkitDocument).webkitFullscreenElement ?? null;
  return target.fullscreenElement ?? webkit;
}

function canFullscreen() {
  const target = doc() as (Document & { fullscreenEnabled?: boolean }) | null;
  if (!target) return false;
  return target.fullscreenEnabled ?? true;
}

function createMovieStore() {
  return create<MovieState>((set, get) => {
    /** Re-reads the element so the UI never drifts from real playback. */
    const sync = () => {
      if (!bound) return;
      set({
        available: bound.readyState >= 2,
        playing: !bound.paused,
        muted: bound.muted,
        fullscreen: fullscreenElement() === bound,
      });
    };

    const onFullscreenChange = () => {
      const fullscreen = Boolean(bound) && fullscreenElement() === bound;
      // Native controls only exist to escape/scrub the fullscreen movie; the
      // on-page controls take over again on exit.
      if (bound) bound.controls = fullscreen;
      set({ fullscreen });
    };

    const listeners = {
      play: sync,
      pause: sync,
      volumechange: sync,
      playing: sync,
      canplay: sync,
      loadeddata: sync,
    } as const;

    /**
     * Starts playback, keeping React in step even when the browser refuses
     * (autoplay policy). Every caller is a gesture or an explicit chapter
     * handoff, so a refusal is only logged.
     */
    const play = () => {
      if (!bound || !bound.paused) return;
      void bound
        .play()
        .then(sync)
        .catch((error) => {
          console.warn("Movie could not play:", error);
          set({ playing: false });
        });
      set({ playing: true });
    };

    const pause = () => {
      if (!bound) return;
      bound.pause();
      set({ playing: false });
    };

    /**
     * Rewinds the bound element to its first frame and starts it playing.
     * Shared by the restart control and the fullscreen "watch it properly"
     * path, which both want the movie from the top.
     */
    const playFromStart = () => {
      if (!bound) return;
      const video = bound as HTMLVideoElement & {
        fastSeek?: (time: number) => void;
      };

      const rewind = () => {
        // `fastSeek` skips the keyframe hunt where a browser offers it.
        if (typeof video.fastSeek === "function") video.fastSeek(0);
        else video.currentTime = 0;
      };

      try {
        rewind();
      } catch {
        // Seeking before the first frame lands throws on some browsers; the
        // rewind is retried once data is in.
        video.addEventListener("loadeddata", rewind, { once: true });
      }

      play();
      set({ playing: true });
    };

    /** Sound on at full volume — fullscreen is the chapter's screening mode. */
    const unmute = () => {
      if (!bound) return;
      bound.muted = false;
      // Some browsers keep a muted-at-birth element silent until the volume is
      // raised explicitly.
      if (bound.volume === 0) bound.volume = 1;
      set({ muted: false });
    };

    return {
      attached: false,
      available: false,
      playing: false,
      muted: true,
      fullscreen: false,
      fullscreenEnabled: canFullscreen(),

      attach: (video) => {
        if (bound === video) {
          sync();
          return;
        }
        get().detach(bound ?? video);

        bound = video;
        (Object.keys(listeners) as Array<keyof typeof listeners>).forEach(
          (event) => video.addEventListener(event, listeners[event]),
        );
        document.addEventListener("fullscreenchange", onFullscreenChange);
        document.addEventListener(
          "webkitfullscreenchange",
          onFullscreenChange,
        );

        set({
          attached: true,
          available: video.readyState >= 2,
          playing: !video.paused,
          muted: video.muted,
          fullscreen: fullscreenElement() === video,
          fullscreenEnabled: canFullscreen(),
        });
      },

      detach: (video) => {
        if (!bound || bound !== video) {
          set({ attached: false, available: false, playing: false });
          return;
        }

        (Object.keys(listeners) as Array<keyof typeof listeners>).forEach(
          (event) => bound?.removeEventListener(event, listeners[event]),
        );
        document.removeEventListener("fullscreenchange", onFullscreenChange);
        document.removeEventListener(
          "webkitfullscreenchange",
          onFullscreenChange,
        );

        const wasFullscreen = fullscreenElement() === bound;
        bound.controls = false;
        bound = null;
        if (wasFullscreen) void exitFullscreen();

        set({
          attached: false,
          available: false,
          playing: false,
          fullscreen: false,
        });
      },

      play: () => play(),

      pause: () => pause(),

      togglePlay: () => {
        if (!bound) return;
        if (bound.paused) play();
        else pause();
      },

      restart: () => playFromStart(),

      toggleMute: () => {
        if (!bound) return;
        if (bound.muted) {
          unmute();
          return;
        }
        bound.muted = true;
        set({ muted: true });
      },

      toggleFullscreen: () => {
        if (!bound) return;
        if (fullscreenElement() === bound) {
          void exitFullscreen();
          return;
        }
        // Fullscreen is the "watch it properly" affordance: it turns the muted
        // ambient render into a real screening, with sound and from the top.
        unmute();
        playFromStart();
        void requestFullscreen(bound)
          .then(sync)
          .catch((error) =>
            console.warn("Fullscreen unavailable for the movie:", error),
          );
      },
    };
  });
}

function requestFullscreen(video: HTMLVideoElement) {
  const webkit = video as WebkitVideo;
  try {
    const call = webkit.requestFullscreen?.bind(video);
    if (call) return Promise.resolve(call());
    const elementCall = webkit.webkitRequestFullscreen?.bind(video);
    if (elementCall) return Promise.resolve(elementCall());
    // iOS hands video elements its own fullscreen presenter.
    const ios = webkit.webkitEnterFullscreen?.bind(video);
    if (ios) {
      ios();
      return Promise.resolve();
    }
  } catch (error) {
    return Promise.reject(error);
  }
  return Promise.reject(new Error("no fullscreen API"));
}

function exitFullscreen() {
  const target = doc() as WebkitDocument | null;
  if (!target) return Promise.resolve();
  try {
    const call = target.exitFullscreen?.bind(target);
    if (call) return Promise.resolve(call()).catch(() => {});
    const fallback = target.webkitExitFullscreen?.bind(target);
    if (fallback) return Promise.resolve(fallback()).catch(() => {});
  } catch {
    // Already out of fullscreen.
  }
  return Promise.resolve();
}

type MovieStore = ReturnType<typeof createMovieStore>;

export const useMovieStore: MovieStore =
  typeof window === "undefined"
    ? createMovieStore()
    : ((window as unknown as { __myCompanyMovie?: MovieStore })
        .__myCompanyMovie ??= createMovieStore());
