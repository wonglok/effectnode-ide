/* ── Attachment asset resolution ──────────────────────────────────────────
 * The uploaded binaries live in `public/attachments/`, so a relative URL is
 * tried first (it resolves under the virtual preview's URL prefix) and an
 * absolute one second (a plain root-served build).
 */

export const APARTMENT_MODEL_SOURCES = [
  "attachments/apartment.glb",
  "/attachments/apartment.glb",
] as const;

export const STUDIO_HDR_SOURCES = [
  "attachments/studio.hdr",
  "/attachments/studio.hdr",
] as const;

export const ONE_PER_SCENE_SOURCES = [
  "attachments/one-per-scene.png",
  "/attachments/one-per-scene.png",
] as const;

/**
 * Resolve the first source that loads. Returns `null` when every candidate
 * fails, so callers can fall back to a plain stage instead of throwing.
 */
export async function loadFirstAsset<T>(
  sources: readonly string[],
  load: (source: string) => Promise<T>,
): Promise<T | null> {
  for (const source of sources) {
    try {
      return await load(source);
    } catch {
      // Fall through to the next URL shape.
    }
  }

  return null;
}
